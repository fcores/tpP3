package ClaseUno;

public class ActividadDos {
    public static void main(String[] args) {
        
        int edad = 24;
        double altura = 1.90;
        char inicial = 'A';
        String residencia = "CABA";

        int operacionUno = edad + 50;
        double operacionDos = altura * 2;
        String operacionTres = "Tu inicial es " + inicial;

        System.out.println(operacionUno);
        System.out.println(operacionDos);
        System.out.println(operacionTres);

    }
}
